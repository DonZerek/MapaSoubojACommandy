package commandPrikazy;

public interface Argument {

	public boolean exists(Argument a);
}
